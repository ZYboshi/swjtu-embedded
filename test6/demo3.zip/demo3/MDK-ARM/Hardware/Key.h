#ifndef __KEY_h
#define __KEY_h

/*ͷ�ļ�����*/
#include "main.h"
#include "gpio.h"
#include "basic.h"


uint8_t key_read(void);

#endif 