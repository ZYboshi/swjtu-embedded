#ifndef __BASIC_h
#define __BASIC_h

/*ͷ�ļ�����*/
#include "main.h"
#include "gpio.h"

void delay_us(uint32_t us);
void delay_ms(uint32_t ms);


#endif 