#ifndef __INIT_HARDWARE_h
#define __INIT_HARDWARE_h

/*ͷ�ļ�����*/
#include "basic.h"
#include "Buzzer.h"
#include "Led.h"
#include "Seg.h"


#endif 